#ifndef FILA_H
#define FILA_H

#include <stdbool.h>

#define MAX_CANAL 100

typedef struct {
    int dados[MAX_CANAL + 1];
    int ini, fim;
} Fila;

void criarFila(Fila* f);
int filaVazia(Fila* f);
void inserirNaFila(Fila* f, int v);
int removerDaFila(Fila* f);

#endif 