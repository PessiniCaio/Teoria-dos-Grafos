#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "bfs.h"

void imprimirCaminho(int cliques, int destino, int prev[], char oper[][4]) {
    if (cliques <= 0) return;

    // Usa um array para empilhar o caminho e depois imprimir na ordem correta
    int caminho[MAX_CANAL];
    int tam = 0;
    for (int v = destino; v != INF; v = prev[v]) {
        caminho[tam++] = v;
    }

    // Imprime o caminho do penúltimo elemento (origem) ao primeiro (antes do destino)
    printf("Observacoes (transicao entre canais): \n\n");
    for (int i = tam - 1; i > 0; --i) {
        int atual = caminho[i];
        int prox = caminho[i - 1];
        printf("%d -> %d (%s)\n", atual, prox, oper[prox]);
    }
    printf("\n-----------------------------------------------------------------");
}

int main() {
    int ini, destino, k;

    // Leitura da primeira linha: canal inicial, canal destino, qtd de canais adultos
    if (fscanf(stdin, "%d %d %d", &ini, &destino, &k) != 3) {
        fprintf(stderr, "Erro de leitura na primeira linha.\n");
        return 1;
    }

    // Leitura da segunda linha: lista de canais adultos
    bool adulto[MAX_CANAL + 1] = {false};
    for (int i = 0, canal; i < k; ++i) {
        if (fscanf(stdin, "%d", &canal) != 1) {
            fprintf(stderr, "Erro de leitura na lista de canais adultos.\n");
            return 1;
        }
        if (canal >= 1 && canal <= MAX_CANAL) {
            adulto[canal] = true;
        }
    }

    /* Vetores auxiliares para o BFS */
    int  visit[MAX_CANAL + 1];
    int  prev[MAX_CANAL + 1];
    char oper[MAX_CANAL + 1][4];

    /* Executa BFS */
    int cliques = BLargura(ini, destino, adulto, visit, prev, oper);

    if (cliques == -1) { // Destino inalcançável
        printf("0\n\n");
        return 0;
    }

    printf("\n-----------------------------------------------------------------\n\n");
    printf("Resposta do algoritmo (numero minimo de cliques): %d cliques\n\n", cliques);

    /* Reconstrói e imprime o caminho, se existir */
    imprimirCaminho(cliques, destino, prev, oper);

    return 0;
}