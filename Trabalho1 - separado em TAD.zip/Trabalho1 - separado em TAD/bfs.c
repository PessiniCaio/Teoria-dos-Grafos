#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "bfs.h"
#include "fila.h"

typedef struct {
    int (*valid)(int);   /* Devolve 1 se a operação pode ser aplicada */
    int (*apply)(int);   /* Calcula o canal gerado */
    char simbolo[4];     /* String a imprimir: "+1", "*2", ... */
} Operacao;

/* --- Funções de validação e aplicação das operações do controle --- */

int soma_valida1(int c) {
    (void)c;
    return 1;
}

int aplica_soma1(int c) {
    if (c == MAX_CANAL) {
        return 1;
    } else {
        return c + 1;
    }
}

int subtracao_valida1(int c) {
    (void)c;
    return 1;
}

int aplica_subtracao1(int c) {
    if (c == 1) {
        return MAX_CANAL;
    } else {
        return c - 1;
    }
}

int multiplicacao_valida2(int c) {
    if (c <= 50) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_multiplicacao2(int c) {
    return c * 2;
}

int multiplicacao_valida3(int c) {
    if (c <= 33) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_multiplicacao3(int c) {
    return c * 3;
}

int divisao_valida2(int c) {
    if (c % 2 == 0) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_divisao2(int c) {
    return c / 2;
}

/* --- Tabela global com as 5 operações possíveis --- */
const Operacao op[5] = {
    {soma_valida1, aplica_soma1, "+1"},
    {subtracao_valida1, aplica_subtracao1, "-1"},
    {multiplicacao_valida2, aplica_multiplicacao2, "*2"},
    {multiplicacao_valida3, aplica_multiplicacao3, "*3"},
    {divisao_valida2, aplica_divisao2, "/2"},
};

/* --- Implementação da Busca em Largura --- */

int BLargura(int origem, int destino, const bool adulto[], int visit[], int prev[], char oper[][4]) {
    Fila fila;

    /* Inicializa visit[] com -1 (não visitado) */
    for (int u = 1; u <= MAX_CANAL; ++u) visit[u] = -1;

    /* Visita o vértice inicial */
    visit[origem] = 1; /* Distância para a origem é 0, mas usamos 1 para diferenciar de "não visitado" */
    prev[origem]  = INF;

    criarFila(&fila);
    inserirNaFila(&fila, origem);

    while (!filaVazia(&fila)) {
        int x = removerDaFila(&fila);

        if (x == destino) break; /* Já achamos o menor caminho */

        /* Para cada vizinho y de x gerado por um botão */
        for (int i = 0; i < 5; ++i) {
            if (!op[i].valid(x)) continue;

            int y = op[i].apply(x);

            /* Ignora o vizinho se for um canal adulto ou já tiver sido visitado */
            if (adulto[y] || visit[y] != -1) continue;

            inserirNaFila(&fila, y);
            visit[y] = visit[x] + 1; /* A distância do vizinho é a do atual + 1 */
            prev[y] = x;
            strcpy(oper[y], op[i].simbolo);
        }
    }

     /* Retorno: número mínimo de cliques; -1 se inalcançável */
     if (visit[destino] == -1) {
        return -1;
     }
     /* A distância real é o valor em visit[] menos 1 */
     return visit[destino] - 1;
}