#ifndef BFS_H
#define BFS_H

#include <stdbool.h>

#define MAX_CANAL 100
#define INF -1

int BLargura(int origem, int destino, const bool adulto[], int visit[], int prev[], char oper[][4]);

#endif