#include "fila.h"

// Inicializa fila (vazia)
void criarFila(Fila* f) {
    f->ini = f->fim = 0;
}

int filaVazia(Fila* f) {
    return f->ini == f->fim;
}

// Insere valor no final da fila
void inserirNaFila(Fila* f, int v) {
    f->dados[f->fim++] = v;
}

// Remove valor do início da fila
int removerDaFila(Fila* f) {
    return f->dados[f->ini++];
}