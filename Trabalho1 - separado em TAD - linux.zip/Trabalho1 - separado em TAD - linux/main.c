#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "bfs.h"

// Reconstrói e imprime a sequência de cliques entre canais
void imprimirCaminho(int cliques, int destino, int prev[], char oper[][4]) {
    if (cliques <= 0) return;

    // Empilha do destino até a origem
    int caminho[MAX_CANAL];
    int tam = 0;
    for (int v = destino; v != INF; v = prev[v]) {
        caminho[tam++] = v;
    }

    // Imprime cada transição com a operação usada
    printf("Observacoes (transicao entre canais): \n\n");
    for (int i = tam - 1; i > 0; --i) {
        int atual = caminho[i];
        int prox = caminho[i - 1];
        printf("%d -> %d (%s)\n", atual, prox, oper[prox]);
    }
    printf("\n-----------------------------------------------------------------");
}

int main() {
    int ini, destino, k;

    // Lê canal inicial, destino e quantidade de canais adultos
    if (fscanf(stdin, "%d %d %d", &ini, &destino, &k) != 3) {
        fprintf(stderr, "Erro de leitura na primeira linha.\n");
        return 1;
    }

    // Leitura da segunda linha: lista de canais adultos
    bool adulto[MAX_CANAL + 1] = {false};
    for (int i = 0, canal; i < k; ++i) {
        if (fscanf(stdin, "%d", &canal) != 1) {
            fprintf(stderr, "Erro de leitura na lista de canais adultos.\n");
            return 1;
        }
        if (canal >= 1 && canal <= MAX_CANAL) {
            adulto[canal] = true;
        }
    }

    // Vetores auxiliares para o BFS
    int  visit[MAX_CANAL + 1];
    int  prev[MAX_CANAL + 1];
    char oper[MAX_CANAL + 1][4];

    // Executa BFS para calcular mínimo de cliques
    int cliques = BLargura(ini, destino, adulto, visit, prev, oper);

    // Se inalcançável, imprime 0 e sai
    if (cliques == -1) { 
        printf("0\n\n");
        return 0;
    }

    // Imprime resultado e caminho
    printf("\n-----------------------------------------------------------------\n\n");
    printf("Resposta do algoritmo (numero minimo de cliques): %d cliques\n\n", cliques);
    imprimirCaminho(cliques, destino, prev, oper);

    return 0;
}