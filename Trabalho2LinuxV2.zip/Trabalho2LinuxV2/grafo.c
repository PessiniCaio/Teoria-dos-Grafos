#include "grafo.h"
#include "heap.h"
#include <stdlib.h>
#include <stdio.h>

#define INF 2147483647

Grafo *grafo_criar(int num_vertices) {
    if (num_vertices <= 0) return NULL;
    Grafo *g = (Grafo *)malloc(sizeof(Grafo));
    if (!g) return NULL;
    g->num_vertices = num_vertices;
    g->adj = (Aresta **)malloc(sizeof(Aresta *) * (num_vertices + 1));
    if (!g->adj) { free(g); return NULL; }
    for (int i = 0; i <= num_vertices; i++) { g->adj[i] = NULL; }
    return g;
}

void grafo_adicionar_aresta(Grafo *g, int u, int v, int p) {
    if (!g || u < 1 || v < 1 || u > g->num_vertices || v > g->num_vertices) return;
    
    Aresta *a1 = (Aresta *)malloc(sizeof(Aresta));
    if (a1) {
        a1->destino = v;
        a1->peso = p;
        a1->proximo = g->adj[u];
        g->adj[u] = a1;
    }
    
    Aresta *a2 = (Aresta *)malloc(sizeof(Aresta));
    if (a2) {
        a2->destino = u;
        a2->peso = p;
        a2->proximo = g->adj[v];
        g->adj[v] = a2;
    }
}

void grafo_liberar(Grafo *g) {
    if (!g) return;
    for (int i = 1; i <= g->num_vertices; i++) {
        Aresta *atual = g->adj[i];
        while (atual) {
            Aresta *prox = atual->proximo;
            free(atual);
            atual = prox;
        }
    }
    free(g->adj);
    free(g);
}


int grafo_menor_caminho(const Grafo *g, int origem, int destino, const int *proibido) {
    if (!g || origem < 1 || origem > g->num_vertices || destino < 1 || destino > g->num_vertices) return -1;
    int *distancia = (int *)malloc(sizeof(int) * (g->num_vertices + 1));
    int *visitado = (int *)malloc(sizeof(int) * (g->num_vertices + 1));
    if (!distancia || !visitado) { free(distancia); free(visitado); return -1; }
    for (int i = 1; i <= g->num_vertices; i++) { distancia[i] = INF; visitado[i] = 0; }
    distancia[origem] = 0;
    HeapMin *heap = heap_criar(g->num_vertices);
    if (!heap) { free(distancia); free(visitado); return -1; }
    heap_inserir(heap, origem, 0);
    while (heap->tamanho > 0) {
        int u;
        int du;
        if (heap_extrair_min(heap, &u, &du) != 0 || visitado[u] || du > distancia[u]) continue;
        visitado[u] = 1;
        if (u == destino) break;
        if (proibido && proibido[u] && u != origem && u != destino) continue;
        for (Aresta *a = g->adj[u]; a != NULL; a = a->proximo) {
            int v = a->destino;
            int p = a->peso;
            if ((proibido && proibido[v] && v != destino) || visitado[v] || distancia[u] == INF) continue;
            int alt = distancia[u] + p;
            if (alt < distancia[v]) { distancia[v] = alt; heap_inserir(heap, v, alt); }
        }
    }
    int resultado = distancia[destino];
    if (resultado == INF) resultado = -1;
    heap_liberar(heap);
    free(distancia);
    free(visitado);
    return resultado;
}