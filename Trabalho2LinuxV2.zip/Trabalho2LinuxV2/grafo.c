#include "grafo.h"
#include <stdlib.h>

#define INF 1000000000

void grafo_criar(Grafo *g, int num_vertices) {
    g->num_vertices = num_vertices;
    for (int i = 1; i <= num_vertices; i++) {
        for (int j = 1; j <= num_vertices; j++) g->adj[i][j] = INF;
        g->adj[i][i] = 0;
    }
}

void grafo_adicionar_aresta(Grafo *g, int u, int v, int p) {
    g->adj[u][v] = p; g->adj[v][u] = p;
}

int grafo_menor_caminho(const Grafo *g, int origem, int destino, const int *proibido) {
    int n = g->num_vertices, dist[MAX_VERTICES], vis[MAX_VERTICES];
    for (int i = 1; i <= n; i++) { dist[i] = INF; vis[i] = 0; }
    dist[origem] = 0;
    for (int it = 0; it < n; it++) {
        int u = -1, best = INF;
        for (int i = 1; i <= n; i++) if (!vis[i] && dist[i] < best) { best = dist[i]; u = i; }
        if (u == -1) break;
        vis[u] = 1;
        if (proibido[u] && u != origem && u != destino) continue;
        for (int v = 1; v <= n; v++) {
            if (vis[v] || g->adj[u][v] == INF) continue;
            if (proibido[v] && v != destino) continue;
            int nd = dist[u] + g->adj[u][v];
            if (nd < dist[v]) dist[v] = nd;
        }
    }
    return dist[destino] == INF ? -1 : dist[destino];
}