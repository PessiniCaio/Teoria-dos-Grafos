#ifndef GRAFO_H
#define GRAFO_H

typedef struct Aresta {
    int destino;
    int peso;
    struct Aresta *proximo;
} Aresta;

typedef struct Grafo {
    int num_vertices;
    Aresta **adj;
} Grafo;

Grafo *grafo_criar(int num_vertices);

void grafo_adicionar_aresta(Grafo *g, int u, int v, int p);

void grafo_liberar(Grafo *g);

int grafo_menor_caminho(const Grafo *g, int origem, int destino, const int *proibido);

#endif 