#ifndef GRAFO_H
#define GRAFO_H

#define MAX_VERTICES 101

typedef struct Grafo {
    int num_vertices;
    int adj[MAX_VERTICES][MAX_VERTICES];
} Grafo;

void grafo_criar(Grafo *g, int num_vertices);
void grafo_adicionar_aresta(Grafo *g, int u, int v, int p);
int grafo_menor_caminho(const Grafo *g, int origem, int destino, const int *proibido);

#endif