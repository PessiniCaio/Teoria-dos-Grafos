#include "heap.h"
#include <stdlib.h>

static void trocar_nos(NoHeap *a, NoHeap *b) {
    NoHeap tmp = *a;
    *a = *b;
    *b = tmp;
}

HeapMin *heap_criar(int capacidade) {
    if (capacidade < 1) capacidade = 1;
    HeapMin *h = (HeapMin *)malloc(sizeof(HeapMin));
    if (!h || !(h->dados = (NoHeap *)malloc(sizeof(NoHeap) * capacidade))) { free(h); return NULL; }
    h->capacidade = capacidade;
    h->tamanho = 0;
    return h;
}

void heap_liberar(HeapMin *h) {
    if (!h) return;
    free(h->dados);
    free(h);
}

static int heap_assegurar_capacidade(HeapMin *h, int nova_capacidade) {
    if (nova_capacidade <= h->capacidade) return 0;
    int cap = h->capacidade;
    while (cap < nova_capacidade) cap *= 2;
    NoHeap *novos = (NoHeap *)realloc(h->dados, sizeof(NoHeap) * cap);
    if (!novos) return -1;
    h->dados = novos;
    h->capacidade = cap;
    return 0;
}

static void heap_subir(HeapMin *h, int idx) {
    while (idx > 0) {
        int pai = (idx - 1) / 2;
        if (h->dados[pai].distancia <= h->dados[idx].distancia) break;
        trocar_nos(&h->dados[pai], &h->dados[idx]);
        idx = pai;
    }
}

static void heap_descer(HeapMin *h, int idx) {
    while (1) {
        int esquerda = 2 * idx + 1;
        int direita = 2 * idx + 2;
        int menor = idx;
        if (esquerda < h->tamanho && h->dados[esquerda].distancia < h->dados[menor].distancia) menor = esquerda;
        if (direita < h->tamanho && h->dados[direita].distancia < h->dados[menor].distancia) menor = direita;
        if (menor == idx) break;
        trocar_nos(&h->dados[menor], &h->dados[idx]);
        idx = menor;
    }
}

void heap_inserir(HeapMin *h, int vertice, int distancia) {
    if (!h || heap_assegurar_capacidade(h, h->tamanho + 1) != 0) return;
    h->dados[h->tamanho].vertice = vertice;
    h->dados[h->tamanho].distancia = distancia;
    h->tamanho++;
    heap_subir(h, h->tamanho - 1);
}

int heap_extrair_min(HeapMin *h, int *vertice, int *distancia) {
    if (!h || h->tamanho == 0) return -1;
    if (vertice) *vertice = h->dados[0].vertice;
    if (distancia) *distancia = h->dados[0].distancia;
    h->dados[0] = h->dados[h->tamanho - 1];
    h->tamanho--;
    if (h->tamanho > 0) heap_descer(h, 0);
    return 0;
}