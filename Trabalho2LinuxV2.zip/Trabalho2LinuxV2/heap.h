#ifndef HEAP_H
#define HEAP_H

typedef struct NoHeap {
    int vertice;
    int distancia;
} NoHeap;

typedef struct HeapMin {
    NoHeap *dados; 
    int capacidade;   
    int tamanho;
} HeapMin;

HeapMin *heap_criar(int capacidade);

void heap_liberar(HeapMin *h);

void heap_inserir(HeapMin *h, int vertice, int distancia);

int heap_extrair_min(HeapMin *h, int *vertice, int *distancia);

#endif