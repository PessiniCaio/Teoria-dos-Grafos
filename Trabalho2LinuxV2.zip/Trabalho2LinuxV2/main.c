#include <stdio.h>
#include <stdlib.h>
#include "grafo.h"

int main(int argc, char *argv[]) {
    if (argc < 2) { fprintf(stderr, "Uso: %s <arquivo_grafo>\n", argv[0]); return 1; }

    FILE *arq = fopen(argv[1], "r");
    if (!arq) { fprintf(stderr, "Nao foi possivel abrir o arquivo %s.\n", argv[1]); return 1; }

    int num_vertices, num_arestas;
    if (fscanf(arq, "%d %d", &num_vertices, &num_arestas) != 2 || num_vertices <= 0 || num_arestas < 0) {
        fprintf(stderr, "Erro ao ler o numero de cidades e estradas do arquivo ou valores invalidos de n ou m.\n");
        fclose(arq); return 1;
    }

    Grafo grafo; 
    grafo_criar(&grafo, num_vertices); 

    for (int i = 0; i < num_arestas; i++) {
        int u, v, p;
        if (fscanf(arq, "%d %d %d", &u, &v, &p) != 3) {
            fprintf(stderr, "Erro ao ler dados da estrada %d no arquivo.\n", i + 1);
            fclose(arq); return 1;
        }
        grafo_adicionar_aresta(&grafo, u, v, p);
    }
    fclose(arq);

    int origem, destino, k;
    printf("Digite a cidade de origem, a cidade de destino e o numero de cidades proibidas: ");
    fflush(stdout);
    if (scanf("%d %d %d", &origem, &destino, &k) != 3) {
        fprintf(stderr, "Erro ao ler origem/destino/numero de proibidas.\n");
        return 1;
    }

    k = (k < 0) ? 0 : ((k > num_vertices) ? num_vertices : k);

    int proibido[MAX_VERTICES]; 
    for (int i = 0; i <= num_vertices; i++) { proibido[i] = 0; }

    for (int i = num_vertices; i > num_vertices - k; i--) {
        if (i >= 1 && i <= num_vertices) { proibido[i] = 1; }
    }

    int distancia = grafo_menor_caminho(&grafo, origem, destino, proibido);
    if (distancia < 0) { printf("YL NAO PODERA REALIZAR ESTA VIAGEM\n"); }
    else { printf("%d\n", distancia); }

    return 0;
}