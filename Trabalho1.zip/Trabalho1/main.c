#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_CANAL 100
#define INF -1

/* Tabela de operações possíveis */
typedef struct {
    int (*valid)(int);   /* devolve 1 se a operação pode ser aplicada */
    int (*apply)(int);   /* canal gerado */
    char simbolo[4];     /* string a imprimir: "+1", "*2", ...        */
}Operacao;

/* Estrutura para a fila */
typedef struct {
    int dados[MAX_CANAL + 1];
    int ini, fim;
}Fila;

void criarFila(Fila* f) {
    f->ini = f->fim = 0;
}

int filaVazia(Fila* f) {
    return f->ini == f->fim;
}

void inserirNaFila(Fila* f, int v) {
    f->dados[f->fim++] = v;
}

int removerDaFila(Fila* f) {
    return f->dados[f->ini++];
}


int soma_valida1(int c) {
    return 1;
}

int aplica_soma1(int c) {
    if (c == MAX_CANAL) {
        return 1;
    } else {
        return c + 1;
    }
}

int subtracao_valida1(int c) {
    return 1;
}

int aplica_subtracao1(int c) {
    if (c == 1) {
        return MAX_CANAL;
    } else {
        return c - 1;
    }
}

int multiplicacao_valida2(int c) {
    if (c <= 50) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_multiplicacao2(int c) {
    return c * 2;
}

int multiplicacao_valida3(int c) {
    if (c <= 33) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_multiplicacao3(int c) {
    return c * 3;
}

int divisao_valida2(int c) {
    if (c % 2 == 0) {
        return 1;
    } else {
        return 0;
    }
}

int aplica_divisao2(int c) {
    return c / 2;
}

const Operacao op[5] = {
    {soma_valida1, aplica_soma1, "+1"},
    {subtracao_valida1, aplica_subtracao1, "-1"},
    {multiplicacao_valida2, aplica_multiplicacao2, "*2"},
    {multiplicacao_valida3, aplica_multiplicacao3, "*3"},
    {divisao_valida2, aplica_divisao2, "/2"},
};

int BLargura(int origem, int destino, const bool adulto[], int visit[], int prev[], char oper[][4]) {
    Fila fila;
    int cont = 0;

    /* inicializa Visit[] com -1 (não visitado) */
    for (int u = 1; u <= MAX_CANAL; ++u) visit[u] = -1;

    /* visita o vértice inicial escolhido pelo usuário */
    visit[origem] = ++cont;      /* ordem de visita começa em 1 */
    prev[origem]  = INF;

    criarFila(&fila);
    inserirNaFila(&fila, origem);

    while (!filaVazia(&fila)) {
        int x = removerDaFila(&fila);

        if (x == destino) break; /* já achamos a menor rota */

        /* para cada vizinho y de x gerado por um botão */
        for (int i = 0; i < 5; ++i) {
            if (!op[i].valid(x)) continue;

            int y = op[i].apply(x);
            if (adulto[y] || visit[y] != -1) continue;

            inserirNaFila(&fila, y);
            visit[y] = visit[x] + 1;
            prev[y] = x;
            strcpy(oper[y], op[i].simbolo);
        }
    }

     /* retorno: número mínimo de cliques; -1 se inalcançável */
     if (visit[destino] == -1) {
        return -1;
     }
     return visit[destino] - 1;
}

int main() {

    int ini, destino, k;
    if (fscanf(stdin, "%d %d %d", &ini, &destino, &k) != 3) {
        fprintf(stderr, "Erro de leitura na primeira linha.\n");
        return 1;
    }

    bool adulto[MAX_CANAL + 1] = {false};
    for (int i = 0, canal; i < k; ++i) {
        if (fscanf(stdin, "%d", &canal) != 1) {
            fprintf(stderr, "Erro de leitura na lista de canais adultos.\n");
            return 1;
        }
        if (canal >= 1 && canal <= MAX_CANAL) adulto[canal] = true;
    }

    /* vetores auxiliares */
    int  visit[MAX_CANAL + 1];
    int  prev [MAX_CANAL + 1];
    char oper [MAX_CANAL + 1][4];

    /* executa BFS */
    int cliques = BLargura(ini, destino, adulto, visit, prev, oper);

    if (cliques == -1) { /* destino inalcançável */
        printf("0\n");
        return 0;
    }

    printf("%d\n", cliques);

    /* reconstrói o caminho: empilha e depois imprime */
    if (cliques > 0) {
        int caminho[MAX_CANAL], tam = 0;
          for (int v = destino; v != INF; v = prev[v]) {
            caminho[tam++] = v;
        }

        for (int i = tam -1; i > 0; --i) {
        int atual = caminho[i];
        int prox = caminho[i - 1];
        printf("%d -> %d (%s)\n", atual, prox, oper[prox]);
    }

    }

    return 0;
}